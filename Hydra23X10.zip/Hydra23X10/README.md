# Hydra23X10
port of old hydra that does not crash on long prints to the new X10 pcb
